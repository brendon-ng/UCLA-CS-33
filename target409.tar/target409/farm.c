/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_217()
{
    return 3334705240U;
}

void setval_444(unsigned *p)
{
    *p = 2428963144U;
}

void setval_447(unsigned *p)
{
    *p = 2488854682U;
}

unsigned addval_226(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_394(unsigned x)
{
    return x + 3267856712U;
}

unsigned addval_185(unsigned x)
{
    return x + 3347662876U;
}

unsigned getval_245()
{
    return 3281031192U;
}

unsigned addval_222(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_149(unsigned x)
{
    return x + 3677934025U;
}

unsigned addval_478(unsigned x)
{
    return x + 3285093884U;
}

void setval_176(unsigned *p)
{
    *p = 2425409033U;
}

unsigned addval_250(unsigned x)
{
    return x + 3989295497U;
}

unsigned getval_357()
{
    return 3767093324U;
}

unsigned addval_238(unsigned x)
{
    return x + 3674263945U;
}

unsigned getval_215()
{
    return 3375940237U;
}

unsigned getval_485()
{
    return 3252717896U;
}

void setval_421(unsigned *p)
{
    *p = 2430635336U;
}

unsigned addval_484(unsigned x)
{
    return x + 3285092532U;
}

unsigned addval_358(unsigned x)
{
    return x + 3281047947U;
}

void setval_398(unsigned *p)
{
    *p = 3225993865U;
}

unsigned getval_482()
{
    return 3531918985U;
}

unsigned getval_349()
{
    return 3529559689U;
}

unsigned addval_216(unsigned x)
{
    return x + 3676357257U;
}

void setval_140(unsigned *p)
{
    *p = 3767093264U;
}

unsigned getval_307()
{
    return 3229926025U;
}

unsigned getval_106()
{
    return 3380134537U;
}

void setval_126(unsigned *p)
{
    *p = 3372797577U;
}

void setval_182(unsigned *p)
{
    *p = 3531918989U;
}

unsigned addval_147(unsigned x)
{
    return x + 3767224321U;
}

unsigned getval_161()
{
    return 2464188744U;
}

unsigned getval_292()
{
    return 2425474697U;
}

unsigned addval_294(unsigned x)
{
    return x + 3281043977U;
}

void setval_120(unsigned *p)
{
    *p = 3675836809U;
}

unsigned getval_173()
{
    return 3353381192U;
}

unsigned getval_430()
{
    return 3682910849U;
}

unsigned getval_148()
{
    return 3515455467U;
}

unsigned addval_146(unsigned x)
{
    return x + 3286280520U;
}

void setval_108(unsigned *p)
{
    *p = 3375944073U;
}

unsigned getval_195()
{
    return 3680551561U;
}

void setval_414(unsigned *p)
{
    *p = 3285290322U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
